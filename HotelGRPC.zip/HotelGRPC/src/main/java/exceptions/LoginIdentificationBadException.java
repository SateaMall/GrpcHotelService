package exceptions;

public class LoginIdentificationBadException extends Exception {
	public LoginIdentificationBadException() {
		
	}
	public LoginIdentificationBadException(String message) {
		super(message);
	}
}
