package repositories;
import models.Chambre;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ChambreRepository extends JpaRepository<Chambre,Long>{

}
