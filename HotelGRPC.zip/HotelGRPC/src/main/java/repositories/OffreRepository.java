package repositories;

import models.Offre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OffreRepository  extends JpaRepository<Offre,Long> {
}
